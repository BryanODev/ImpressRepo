# Impress Shopify — Sticker: bloqueo de Contour Cut + zoom/pan de vista

Paquete **solo de reemplazos**, no tema Shopify completo. Base: `Shopify.zip` más las cuatro modificaciones de `Impress-Shopify-Contour-Cut-Altura-y-Editor.zip` previamente entregadas.

## Instalación

En **Editar código** del tema de desarrollo, reemplazar solamente los archivos en sus mismas rutas:

- `assets/impress-sticker-editor.js`
- `assets/impress-sticker-configurator.js`
- `assets/impress-sticker-configurator.css`
- `sections/impress-sticker-configurator.liquid`

Después de guardar, actualizar con recarga forzada en la página de stickers. No cambiar productos, variantes, precios ni metafields en Shopify Admin. No instalar el ZIP como tema completo.

## Cómo funciona

**Contour Cut**
- El arte queda automáticamente **centrado**; no se puede mover con el mouse ni con «Centrar arte».
- No permite modificar escala ni rotación, tampoco mediante arrastrar los manejadores; se mantienen las guías, borde y herramientas de fondo.
- Se mantiene la presentación de tamaños por altura (por ejemplo, `2 in de alto`) utilizando **sin alterar** el valor real de Shopify (`2 x 2 in`) para el ID de variante, precio, cantidad y complementos.
- Al cambiar a Contour Cut desde otra forma, se restablecen posición, escala y rotación del arte y cualquier zoom/pan de la vista.

**Square y Circular**
- **Rueda del mouse sobre la vista de edición:** ampliar/reducir la **vista**, no el arte ni la página web. Zoom anclado a la posición del cursor.
- **Rango:** 100% (vista original) a 400% (4×), con botones `−`, `+`, porcentaje y `↺` para restablecer la vista.
- **Botón central presionado + arrastrar:** desplazar (*pan*) la **vista**. No modifica la posición del arte.
- **Botón izquierdo + arrastrar el arte:** mover el **diseño** (como antes). Los sliders Escala / Rotación también editan el arte, no la vista.
- El botón **Centrar arte** afecta al diseño; `↺` afecta únicamente a la vista. La barra de zoom se oculta en Contour Cut y en «Vista final».

## Garantía de separación

La navegación de la vista (`zoom`, `panX`, `panY`) se mantiene en estado separado del arte (`x`, `y`, `scale`, `angle`) y nunca entra en los datos enviados al carrito, el historial de edición ni los PNG exportados. Ningún precio o variante de Shopify fue cambiado.

## Comprobaciones locales

Pruebas con Chromium: Contour Cut sin movimiento, escala ni rotación; Square con rueda que evita el scroll de la página, zoom limitado a 4×, pan central sin alterar arte, movimiento normal con botón izquierdo y restauración de la vista; igualdad SHA-256 del PNG exportado antes/después de zoom/pan; ID de variante/precio intactos. **Pruebas del checkout Shopify real no realizadas.**
