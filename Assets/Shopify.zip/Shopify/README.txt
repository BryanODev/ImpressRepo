IMPRESS STATIC LOGOS — OPACITY + FADE-IN

INSTALL
Replace only sections/impress-clients-static.liquid in your Shopify development theme.
No logo uploads, block reconfiguration, or other theme files are needed.

THEME EDITOR
Impress Static Logos → Logo visibility & animation
- Logo opacity: 20% to 100% (default 100%, same visual as today)
- Fade in when entering view: on/off (default on)
- Fade-in duration: 200 to 2000 ms (default 800 ms)
- Delay between logos: 0 to 250 ms (default 75 ms)

BEHAVIOR
- Each logo fades into place only the FIRST time the section enters the view.
- Scrolling away and back does not replay the effect.
- Opacity affects logos only, not the heading or background.
- Hover lift remains available and preserves your chosen opacity.
- Reduced-motion preference skips the animation.
- If JS does not load, all logos remain visible.
- Existing two-row counts, spacing, widths and uploaded images stay unchanged.

IMPORTANT
Local schema/code checks completed. Verify the section in Shopify Theme Editor after upload.
